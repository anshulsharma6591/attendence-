# 📘 Attendance Tracker App

A simple web app to track class attendance.  
- Highlight students absent today.  
- Extra highlight if absent more than 3 times.  
- Search students.  
- Save & Load attendance (local storage).  
- View attendance history (per day).

---

## 🚀 How to Run

1. Download this repository as ZIP or clone it:
   ```bash
   git clone https://github.com/YOUR-USERNAME/attendance-app.git
   ```
2. Open `index.html` in your browser.
3. Start marking attendance!

---

## 🌐 Deploy Online with GitHub Pages

1. Push this repository to your GitHub account.  
2. Go to **Settings → Pages**.  
3. Under **Source**, choose `main branch` → `/ (root)`.  
4. Click **Save**.  
5. Your app will be live at:
   ```
   https://your-username.github.io/attendance-app/
   ```

---

✅ That’s it! Now your attendance app is online 🎉
